Flappy Bird is an arcade-style game in which the player controls the bird Faby, which moves persistently to the right. The player is tasked with navigating Faby through pairs of pipes that have equally sized gaps placed at random heights.

Instructions:- 
To jump use the space bar or the left mouse button.

Made this only for fun!
Thanks!
